<div class="box">
  <div class="box-body">
    <h4>
    	<p>Kode Project: W-181226-17IN</p>
    	<p>Terima kasih telah menggunakan aplikasi <strong>WinTaris</strong> karya <strong><a href="https://www.wildanfuady.com">Wildan Fuady, S. Kom</a></strong>. </p>
    	<p>Aplikasi ini bersifat open souce dan bisa dikembangkan namun untuk tidak menghapus copyright. Bila ingin melakukan pengembangan tambahan, silahkan hubungi <b>wildanfuady@gmail.com</b></p>
    </h4>
   </div>
</div>
